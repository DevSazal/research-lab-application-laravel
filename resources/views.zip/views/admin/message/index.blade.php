@extends('layouts.messenger')

@section('title', 'Messages - ')
@section('pagetitle', 'Cyber Research Lab | Inbox')


@section('content')
            <div class="col">
                



                <div class="empty-state no-selection">
                    <strong class="font-accent">Select a Conversation</strong>
                    <small>Try selecting a conversation or searching for someone specific.</small>
                </div>


                

            </div>
@endsection